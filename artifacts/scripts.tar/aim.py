import json
import sys
import traceback
from java.nio.charset import StandardCharsets
from org.apache.commons.io import IOUtils
from org.apache.nifi.processor.io import StreamCallback, InputStreamCallback, OutputStreamCallback
from org.python.core.util import StringUtil
import traceback

SOURCE_IM = "inventory manager"
SOURCE_RTV = "rtv"

POST = "POST"
PUT = "PUT"
DELETE = "DELETE"
TAG_SOURCE = "source"


class WriteCallback(OutputStreamCallback):
    def __init__(self):
        self.content = None
        self.charset = StandardCharsets.UTF_8

    def process(self, outputStream):
        bytes = bytearray(self.content.encode('utf-8'))
        outputStream.write(bytes)


class TransformCallback(InputStreamCallback):

    def __init__(self, im_url, tag_list):
        self.url = im_url
        self.output = {}
        self.tag_list_to_check_if_same_data = tag_list.encode('ascii', 'ignore').split(',')

    '''
     item_inventory_manager is an object
     item_id is the inventory item_inventory_manager id from the Inventory Manager Source
     for PUT the RTV data is needed , but the update will be done using the inventory manager id and
     the priority set in inventory manager
     the request body has all the keys from the item, excepting the source
    '''

    def get_request_details_for(self, method, inventory_item, im_item=None):
        response = {}
        response["url"] = self.url
        response["method"] = method

        if method == DELETE:
            response["url"] = response["url"] + inventory_item["id"]
            return response

        request_body = inventory_item
        del request_body["source"]
        response["body"] = request_body

        if method == PUT and im_item:
            response["url"] = response["url"] + im_item["id"]
            response["body"]["priority"] = im_item["priority"]
            response["body"]["creationTime"] = im_item["creationTime"]
            response["body"]["id"] = im_item["id"]
            return response

        if method == POST:
            del request_body["id"]

        return response

    '''
    check if 2 dictionaries/json have the same data
    for a defined json tag list
    '''

    def different_data(self, item_inventory_manager, item_rightv):
        for tag in self.tag_list_to_check_if_same_data:
            if item_inventory_manager[tag] != item_rightv[tag]:
                log.debug(
                    "[different_data method]: The data from RiGHTv is different from the one in Inventory Manager")
                return True
        log.debug(
            "[different_data method]: The data from RiGHTv is the same as the one in Inventory Manager and the PUT request is not necessary")
        return False

    '''
    searches into a json/dict to find an item having a specified external id and a given source
    '''

    @staticmethod
    def get_item_by_source(source, all_data):
        for item in all_data:
            if item and item[TAG_SOURCE] == source:
                return item
        return None

    def generate_crud_request_info(self, inventory_items):
        log.debug(
            "[generate_crud_request_info method]: received data from " + str(len(inventory_items)) + " source(s)")
        how_many_data_source = len(inventory_items)
        if how_many_data_source == 1:
            inventory_item = inventory_items[0]
            if inventory_item[TAG_SOURCE] == SOURCE_IM:
                log.debug("[generate_crud_request_info method]: The request will have DELETE method")
                return self.get_request_details_for(DELETE, inventory_item)
            if inventory_item[TAG_SOURCE] == SOURCE_RTV:
                log.debug("[generate_crud_request_info method]: The request will have POST method")
                return self.get_request_details_for(POST, inventory_item)
        else:
            log.debug("[generate_crud_request_info method]: The request will have PUT method")
            data_im = self.get_item_by_source(SOURCE_IM, inventory_items)
            data_rtv = self.get_item_by_source(SOURCE_RTV, inventory_items)
            if self.different_data(data_im, data_rtv):
                return self.get_request_details_for(PUT, data_rtv, data_im)

    def process(self, inputStream):
        try:
            inputText = IOUtils.toString(inputStream, StandardCharsets.UTF_8)
            inputObj = json.loads(inputText)
            log.debug("[process method]: Processing the data from the input flow....")
            self.output = self.generate_crud_request_info(inputObj)
            log.debug("[process method]: Sending the output to the output flow....")

        except Exception as e:
            traceback.print_exc(file=sys.stdout)
            raise


flowFile = session.get()
if flowFile != None:
    try:
        url = json.loads(flowFile.getAttribute("configResponseBody"))["inventoryItemsUri"]
        tags = json.loads(flowFile.getAttribute("configResponseBody"))["tagsToCheckIfSameData"]

        callback = TransformCallback(im_url=url, tag_list=tags)
        session.read(flowFile, callback)

        if callback.output:
            allAttributes = {
                'url': callback.output["url"],
                'method': callback.output["method"]
            }
            log.debug("The URL used to make the request is: " + callback.output["url"])
            log.debug("The METHOD used to make the request is: " + callback.output["method"])
            if 'body' in callback.output:
                writeCallback = WriteCallback()
                writeCallback.content = json.dumps(callback.output['body'])
                session.write(flowFile, writeCallback)
                log.debug("The BODY used to make the " + callback.output["method"] + " request is: "
                          + json.dumps(callback.output["body"]))

            flowFile = session.putAllAttributes(flowFile, allAttributes)
            if callback.output["method"] == DELETE:
                session.adjustCounter("deleteCounter", 1, True)
            if callback.output["method"] == POST:
                session.adjustCounter("postCounter", 1, True)

            if callback.output["method"] == PUT:
                session.adjustCounter("updateCounter", 1, True)
            session.transfer(flowFile, REL_SUCCESS)
            session.commit()
        else:
            session.adjustCounter("skippedCounter", 1, True)
            session.transfer(flowFile, REL_FAILURE)
    except Exception as e:
        log.error(str(e))
        flowFile = session.putAttribute(flowFile, 'python_error', str(e))
        session.transfer(flowFile, REL_FAILURE)
