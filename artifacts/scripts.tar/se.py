import json
flowFile = session.get()
if flowFile != None:
    segmentType = flowFile.getAttribute("segmentType")
    segmentQueryParam = flowFile.getAttribute("segmentQueryParam")
    segmentRtvQuery = json.loads(flowFile.getAttribute("configResponseBody"))["rtvQueries"]
    segmentRtvQueryAttr = ""
    if segmentRtvQuery[segmentType]:
        segmentRtvQueryAttr = segmentRtvQuery[segmentType] + "'" + segmentQueryParam + "'"
    flowFile = session.putAttribute(flowFile, "segmentRtvQuery", segmentRtvQueryAttr)
    session.transfer(flowFile, REL_SUCCESS)
