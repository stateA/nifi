import json
flowFile = session.get()
if flowFile != None:
	offset = flowFile.getAttribute("offset")
	limit = flowFile.getAttribute("limit")
	newOffset = int(offset) + int(limit)
	flowFile = session.putAttribute(flowFile, "offset", str(newOffset))
	session.transfer(flowFile, REL_SUCCESS)
